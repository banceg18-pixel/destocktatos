<?php
/**
 * Plugin Name: Destocktatos — Administration du site
 * Description: Espace d'administration complet du site Destocktatos (Next.js) : produits, catégories, pages, articles, FAQ, menus, réglages, et gestion de la boutique (commandes, clients, codes promo, avis, messages, newsletter, stock).
 * Version: 2.7.0
 * Requires PHP: 8.1
 * License: GPL-2.0-or-later
 * Text Domain: tatos-headless
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TATOS_HEADLESS_VERSION', '2.7.0');

/* -------------------------------------------------------------------------
 * Types de contenu et taxonomies
 * ---------------------------------------------------------------------- */
add_action('init', function () {
    register_post_type('produit', [
        'label' => 'Produits',
        'labels' => ['singular_name' => 'Produit', 'add_new_item' => 'Ajouter un produit', 'edit_item' => 'Modifier le produit'],
        'public' => true,
        'show_in_rest' => true,
        'rest_base' => 'produits',
        'menu_icon' => 'dashicons-cart',
        'supports' => ['title', 'editor', 'thumbnail', 'custom-fields', 'excerpt'],
        'has_archive' => false,
        'rewrite' => ['slug' => 'boutique'],
    ]);

    register_taxonomy('categorie_produit', ['produit'], [
        'label' => 'Catégories produit',
        'hierarchical' => true,
        'show_in_rest' => true,
        'rest_base' => 'categories-produit',
        'rewrite' => ['slug' => 'categorie'],
    ]);

    register_post_type('faq', [
        'label' => 'FAQ',
        'labels' => ['singular_name' => 'Question'],
        'public' => false,
        'show_ui' => true,
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-editor-help',
        'supports' => ['title', 'editor', 'page-attributes'],
    ]);
    register_taxonomy('faq_categorie', ['faq'], [
        'label' => 'Catégories FAQ',
        'hierarchical' => true,
        'show_ui' => true,
        'show_in_rest' => true,
    ]);

    // Champs produit (exposés dans l'API REST, modifiables dans l'éditeur).
    $product_meta = [
        'tatos_id' => 'string',
        'marque' => 'string',
        'modele' => 'string',
        'prix' => 'number',
        'promotion_prix' => 'number',
        'stock' => 'integer',
        'caracteristiques' => 'string', // JSON {profondeur, largeur, hauteur, poids}
        'garantie' => 'string', // JSON {duree, descriptif}
        'pose' => 'string',
        'couleurs' => 'string', // JSON ["#fff"]
        'sous_categories' => 'string', // JSON ["hublot"]
        'connecter' => 'boolean',
        'vedette' => 'boolean',
        'magasin' => 'boolean',
        'sonore' => 'integer',
        'image_principale' => 'string',
        'images' => 'string', // JSON ["url", ...]
        'etiquette_energie' => 'string',
        'meta_title' => 'string',
        'meta_description' => 'string',
    ];
    foreach ($product_meta as $key => $type) {
        register_post_meta('produit', $key, [
            'type' => $type,
            'single' => true,
            'show_in_rest' => true,
            'auth_callback' => fn() => current_user_can('edit_posts'),
        ]);
    }

    foreach (['ordre' => 'integer', 'image' => 'string', 'description_courte' => 'string'] as $key => $type) {
        register_term_meta('categorie_produit', $key, ['type' => $type, 'single' => true, 'show_in_rest' => true]);
    }

    // Données structurées des pages (héros, cartes…) : JSON identique aux fichiers data/content/pages/*.json.
    foreach (['tatos_data', 'tatos_meta_title', 'tatos_meta_description'] as $key) {
        register_post_meta('page', $key, [
            'type' => 'string',
            'single' => true,
            'show_in_rest' => true,
            'auth_callback' => fn() => current_user_can('edit_pages'),
        ]);
    }

    register_nav_menus(['header' => 'Menu principal (en-tête)', 'footer-legal' => 'Liens légaux (pied de page)']);
});

/* -------------------------------------------------------------------------
 * Réglages du site (coordonnées, horaires, webhook)
 * ---------------------------------------------------------------------- */
const TATOS_SETTINGS_FIELDS = [
    'siteName' => 'Nom du site',
    'description' => 'Description',
    'email' => 'Email de contact',
    'phone' => 'Téléphone',
    'phoneIntl' => 'Téléphone (format international)',
    'addressLine' => 'Adresse',
    'postalCode' => 'Code postal',
    'city' => 'Ville',
    'country' => 'Pays',
    'hours' => 'Horaires (pied de page)',
    'storeHours' => 'Horaires du magasin',
    'mapQuery' => 'Adresse pour la carte',
    'bannerMessage1' => 'Message 1',
    'bannerMessage2' => 'Message 2 (alterne avec le 1, facultatif)',
    'bankHolder' => 'Titulaire du compte',
    'bankName' => 'Banque',
    'bankIban' => 'IBAN',
    'bankBic' => 'BIC',
    'bankReference' => 'Communication à indiquer sur le virement',
    'legalName' => 'Dénomination sociale',
    'legalForm' => 'Forme juridique',
    'legalCapital' => 'Capital social',
    'legalSiren' => 'Numéro SIREN',
    'legalSiret' => 'Numéro SIRET (siège)',
    'legalRcs' => 'Numéro RCS',
    'legalRcsRegistration' => 'Inscription au RCS (greffe et date)',
    'legalVat' => 'N° TVA intracommunautaire',
    'legalHeadOffice' => 'Siège social',
    'legalEstablishment' => 'Établissement (adresse d\'exploitation)',
    'legalDirector' => 'Dirigeant / gérant',
    'legalMediatorName' => 'Médiateur de la consommation (nom)',
    'legalMediatorUrl' => 'Médiateur de la consommation (site internet)',
    'siteUrl' => 'Adresse publique du site, commençant par https://',
    'adminApiSecret' => "Clé d'administration (ADMIN_API_SECRET du site)",
    'webhookUrl' => 'URL du webhook (facultatif : adresse du site + /api/webhooks/wordpress par défaut)',
    'webhookSecret' => 'Secret du webhook (facultatif : clé d\'administration par défaut)',
];

/** Réglages techniques (liaison avec le site), regroupés à part sur la page de réglages. */
const TATOS_TECHNICAL_FIELDS = ['siteUrl', 'adminApiSecret', 'webhookUrl', 'webhookSecret'];
const TATOS_SECRET_FIELDS = ['adminApiSecret', 'webhookSecret'];
/** Bandeau rouge fixé tout en haut du site (laisser vide pour le masquer). */
const TATOS_BANNER_FIELDS = ['bannerMessage1', 'bannerMessage2'];
/** Coordonnées bancaires du virement : imprimées sur la facture et envoyées au client à la commande. */
const TATOS_BANK_FIELDS = ['bankHolder', 'bankName', 'bankIban', 'bankBic', 'bankReference'];
/** Compte fourni par le gérant, enregistré à la mise à jour si aucun IBAN n'est saisi. */
const TATOS_BANK_DEFAULTS = ['bankName' => 'BforBank', 'bankIban' => 'FR76 1621 8000 0140 1214 8835 165', 'bankBic' => 'BFBKFRP1', 'bankReference' => 'MJ-MUBVYNWU-379C'];
/** Société qui exploite le site : mentions légales, CGV, confidentialité, factures (l'établissement = l'adresse ci-dessus). */
const TATOS_LEGAL_FIELDS = ['legalName', 'legalForm', 'legalCapital', 'legalSiren', 'legalSiret', 'legalRcs', 'legalRcsRegistration', 'legalVat', 'legalHeadOffice', 'legalEstablishment', 'legalDirector', 'legalMediatorName', 'legalMediatorUrl'];
const TATOS_LEGAL_DEFAULTS = [
    'legalName' => 'REIMS GOLD',
    'legalForm' => 'SARL, société à responsabilité limitée',
    'legalCapital' => '1 000,00 €',
    'legalSiren' => '823 456 777',
    'legalSiret' => '823 456 777 00015',
    'legalRcs' => '823 456 777 R.C.S. Reims',
    'legalRcsRegistration' => 'inscrite au greffe de Reims le 02/11/2016',
    'legalVat' => 'FR48823456777',
    'legalHeadOffice' => '3 Rue Émile Zola, 51100 Reims, France',
    'legalEstablishment' => '65 Rue d’Aigremont, 78300 Poissy',
    'legalDirector' => 'Jasmine Touvoli',
];

function tatos_settings(): array
{
    $defaults = [
        'siteName' => 'Destocktatos',
        'description' => 'Électroménager de qualité au meilleur prix',
        'country' => 'France',
    ];
    return array_merge($defaults, (array) get_option('tatos_settings', []));
}

add_action('admin_menu', function () {
    add_options_page('Site et magasin', 'Site et magasin', 'manage_options', 'tatos-headless', function () {
        $s = tatos_settings();
        echo '<div class="wrap"><h1>Réglages du site</h1>';
        if (isset($_GET['tatos_check'])) {
            $ping = tatos_site_request('GET', 'ping', null, 10);
            echo $ping['ok']
                ? '<div class="notice notice-success"><p>Liaison réussie avec ' . esc_html($ping['data']['site'] ?? tatos_site_url()) . '. Emails : ' . (!empty($ping['data']['smtp']) ? 'envoi actif' : 'pas encore envoyés (serveur d\'envoi SMTP à configurer sur le site, voir le guide d\'utilisation)') . '.</p></div>'
                : '<div class="notice notice-error"><p>' . esc_html($ping['error']) . '</p></div>';
            // Mise à jour instantanée : le site reçoit-il les modifications faites ici ?
            $hook = tatos_send_webhook('ping', [], true);
            $code = is_wp_error($hook) ? 0 : (int) wp_remote_retrieve_response_code($hook);
            echo $code === 200
                ? '<div class="notice notice-success"><p>Mise à jour instantanée active : chaque modification enregistrée ici apparaît sur le site en quelques secondes.</p></div>'
                : '<div class="notice notice-error"><p>Mise à jour instantanée en échec ('
                    . esc_html(is_wp_error($hook) ? $hook->get_error_message() : ($code === 401 ? 'clé refusée par le site : vérifiez la clé d\'administration ou le secret du webhook' : 'réponse HTTP ' . $code))
                    . '). Les modifications n\'arriveront pas sur le site tant que ce point n\'est pas corrigé.</p></div>';
        }
        echo '<form method="post" action="options.php">';
        settings_fields('tatos_settings');
        $groups = [
            'Coordonnées affichées sur le site' => array_diff(array_keys(TATOS_SETTINGS_FIELDS), TATOS_TECHNICAL_FIELDS, TATOS_BANNER_FIELDS, TATOS_BANK_FIELDS, TATOS_LEGAL_FIELDS),
            'Informations légales (mentions légales, CGV, confidentialité, factures)' => TATOS_LEGAL_FIELDS,
            'Bandeau du haut de page (laisser vide pour le masquer)' => TATOS_BANNER_FIELDS,
            'Paiement par virement (coordonnées imprimées sur la facture envoyée au client)' => TATOS_BANK_FIELDS,
            'Liaison avec le site (technique)' => TATOS_TECHNICAL_FIELDS,
        ];
        foreach ($groups as $title => $keys) {
            echo '<h2>' . esc_html($title) . '</h2><table class="form-table">';
            foreach ($keys as $key) {
                $type = in_array($key, TATOS_SECRET_FIELDS, true) ? 'password' : 'text';
                printf(
                    '<tr><th><label for="%1$s">%2$s</label></th><td><input class="%5$s" type="%4$s" id="%1$s" name="tatos_settings[%1$s]" value="%3$s" autocomplete="off"></td></tr>',
                    esc_attr($key),
                    esc_html(TATOS_SETTINGS_FIELDS[$key]),
                    esc_attr($s[$key] ?? ''),
                    $type,
                    in_array($key, TATOS_BANNER_FIELDS, true) ? 'large-text' : 'regular-text'
                );
            }
            echo '</table>';
        }
        submit_button('Enregistrer les réglages');
        echo '</form>';
        printf('<p><a class="button" href="%s">Vérifier la liaison avec le site</a></p>', esc_url(add_query_arg('tatos_check', '1')));
        echo '<h2>Contenus du site</h2><p class="description" style="max-width:720px">Remplit WordPress avec les contenus actuels du site : coordonnées, pages, articles, FAQ, menus, catégories et produits. À faire une fois, après avoir enregistré la liaison ci-dessus. Relancer l\'import met à jour les contenus sans créer de doublons (vos modifications faites dans WordPress sur ces mêmes contenus seraient remplacées).</p>';
        printf('<p><button type="button" class="button button-primary" id="tatos-import" data-nonce="%s">Importer les contenus du site</button></p><div id="tatos-import-log" class="tatos-import-log" aria-live="polite"></div></div>', esc_attr(wp_create_nonce('tatos_import')));
    });
});

add_action('admin_init', function () {
    register_setting('tatos_settings', 'tatos_settings', [
        'type' => 'array',
        'sanitize_callback' => function ($input) {
            $out = [];
            foreach (array_keys(TATOS_SETTINGS_FIELDS) as $key) {
                $out[$key] = isset($input[$key]) ? sanitize_text_field($input[$key]) : '';
            }
            return $out;
        },
    ]);
});

/* -------------------------------------------------------------------------
 * Endpoints REST /tatos/v1
 * ---------------------------------------------------------------------- */
function tatos_json_meta($post_id, string $key, $fallback)
{
    $raw = get_post_meta($post_id, $key, true);
    if ($raw === '' || $raw === null) {
        return $fallback;
    }
    $decoded = json_decode((string) $raw, true);
    return $decoded === null ? $fallback : $decoded;
}

/**
 * Texte brut d'un contenu WordPress : commentaires de blocs et vraies balises retirés, entités
 * décodées. Un « < » isolé (« < 30 min ») est conservé, contrairement à wp_strip_all_tags().
 */
function tatos_plain_text(string $html): string
{
    $text = preg_replace('/<!--.*?-->/s', '', $html);
    $text = preg_replace('/<\/?[a-zA-Z][^>]*>/', '', $text);
    return html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/** Slug public : WordPress limite post_name à 200 caractères, le slug d'origine complet est conservé en méta. */
function tatos_product_slug(WP_Post $p): string
{
    $full = (string) get_post_meta($p->ID, 'tatos_slug', true);
    return $full !== '' && str_starts_with($full, $p->post_name) ? $full : $p->post_name;
}

/** Identifiant commercial du produit (identique à la base du frontend), 24 caractères. */
function tatos_product_id(int $post_id): string
{
    return get_post_meta($post_id, 'tatos_id', true) ?: 'wp' . str_pad((string) $post_id, 22, '0', STR_PAD_LEFT);
}

function tatos_product_to_array(WP_Post $p): array
{
    $terms = wp_get_post_terms($p->ID, 'categorie_produit');
    $cat = $terms && !is_wp_error($terms) ? $terms[0] : null;
    $promo = get_post_meta($p->ID, 'promotion_prix', true);
    $sonore = get_post_meta($p->ID, 'sonore', true);
    $thumb = get_the_post_thumbnail_url($p, 'full');
    return [
        'id' => tatos_product_id($p->ID),
        'wpId' => $p->ID,
        'slug' => tatos_product_slug($p),
        // post_title brut : get_the_title() appliquerait wptexturize (guillemets typographiques).
        'titre' => $p->post_title,
        'marque' => (string) get_post_meta($p->ID, 'marque', true),
        'modele' => (string) get_post_meta($p->ID, 'modele', true),
        'prix' => (float) get_post_meta($p->ID, 'prix', true),
        'promotionPrix' => $promo === '' ? null : (float) $promo,
        'stock' => (int) get_post_meta($p->ID, 'stock', true),
        'categorie' => $cat ? $cat->name : 'autres',
        'categorieSlug' => $cat ? $cat->slug : 'autres',
        'sousCategorie' => tatos_json_meta($p->ID, 'sous_categories', []),
        'description' => tatos_plain_text($p->post_content),
        'caracteristiques' => tatos_json_meta($p->ID, 'caracteristiques', new stdClass()),
        'garantie' => tatos_json_meta($p->ID, 'garantie', null),
        'pose' => get_post_meta($p->ID, 'pose', true) ?: null,
        'couleur' => tatos_json_meta($p->ID, 'couleurs', []),
        'connecter' => (bool) get_post_meta($p->ID, 'connecter', true),
        'vedette' => (bool) get_post_meta($p->ID, 'vedette', true),
        'magasin' => (bool) get_post_meta($p->ID, 'magasin', true),
        'sonore' => $sonore === '' ? null : (int) $sonore,
        'imagePrincipale' => $thumb ?: (get_post_meta($p->ID, 'image_principale', true) ?: null),
        'images' => tatos_json_meta($p->ID, 'images', []),
        'etiquetteEnergie' => get_post_meta($p->ID, 'etiquette_energie', true) ?: null,
        'metaTitle' => get_post_meta($p->ID, 'meta_title', true) ?: null,
        'metaDescription' => get_post_meta($p->ID, 'meta_description', true) ?: null,
        'createdAt' => get_post_time('c', true, $p),
        'updatedAt' => get_post_modified_time('c', true, $p),
    ];
}

function tatos_menu_items(string $location): array
{
    $locations = get_nav_menu_locations();
    if (empty($locations[$location])) {
        return [];
    }
    $items = wp_get_nav_menu_items($locations[$location]) ?: [];
    $home = untrailingslashit(home_url());
    return array_map(function ($item) use ($home) {
        $url = $item->url;
        if (str_starts_with($url, $home)) {
            $url = substr($url, strlen($home)) ?: '/';
        }
        $out = ['label' => html_entity_decode($item->title, ENT_QUOTES), 'href' => $url];
        $dataCy = get_post_meta($item->ID, '_tatos_data_cy', true);
        if ($dataCy) {
            $out['dataCy'] = $dataCy; // attribut data-cy d'origine (tests E2E)
        }
        return $out;
    }, $items);
}

/**
 * Réponses de l'API REST jamais mises en cache devant WordPress (LiteSpeed Cache, CDN de l'hébergeur) :
 * le site garde sa propre copie des contenus et la renouvelle dès qu'ils changent (webhook). Une réponse
 * gardée en cache lui renverrait l'ancienne version pendant des heures.
 */
add_filter('rest_post_dispatch', function ($response) {
    if ($response instanceof WP_HTTP_Response) {
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->header('X-LiteSpeed-Cache-Control', 'no-cache');
    }
    do_action('litespeed_control_set_nocache', 'API REST lue par le site');
    return $response;
});

add_action('rest_api_init', function () {
    $public = '__return_true';

    register_rest_route('tatos/v1', '/settings', [
        'methods' => 'GET',
        'permission_callback' => $public,
        'callback' => function () {
            $s = tatos_settings();
            unset($s['webhookUrl'], $s['webhookSecret'], $s['adminApiSecret'], $s['siteUrl']);
            return rest_ensure_response($s);
        },
    ]);

    register_rest_route('tatos/v1', '/menus', [
        'methods' => 'GET',
        'permission_callback' => $public,
        'callback' => fn() => rest_ensure_response([
            'header' => tatos_menu_items('header'),
            'footerLegal' => tatos_menu_items('footer-legal'),
        ]),
    ]);

    register_rest_route('tatos/v1', '/faq', [
        'methods' => 'GET',
        'permission_callback' => $public,
        'callback' => function () {
            $out = [];
            $cats = get_terms(['taxonomy' => 'faq_categorie', 'hide_empty' => true]);
            usort($cats, fn($a, $b) => (int) get_term_meta($a->term_id, 'ordre', true) <=> (int) get_term_meta($b->term_id, 'ordre', true));
            foreach ($cats as $cat) {
                $posts = get_posts(['post_type' => 'faq', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'tax_query' => [['taxonomy' => 'faq_categorie', 'terms' => $cat->term_id]]]);
                $out[] = [
                    'title' => $cat->name,
                    'items' => array_map(fn($p) => ['question' => $p->post_title, 'answer' => tatos_plain_text($p->post_content)], $posts),
                ];
            }
            return rest_ensure_response($out);
        },
    ]);

    // Page brute (contenu non filtré par the_content : pas de wpautop ni de wptexturize),
    // découpée en sections <h2> par le frontend.
    register_rest_route('tatos/v1', '/pages/(?P<slug>[a-z0-9-]+)', [
        'methods' => 'GET',
        'permission_callback' => $public,
        'callback' => function (WP_REST_Request $req) {
            $page = get_page_by_path($req['slug'], OBJECT, 'page');
            if (!$page || $page->post_status !== 'publish') {
                return new WP_Error('tatos_not_found', 'Page introuvable', ['status' => 404]);
            }
            $data = json_decode((string) get_post_meta($page->ID, 'tatos_data', true), true);
            return rest_ensure_response([
                'slug' => $page->post_name,
                'title' => $page->post_title,
                'content' => $page->post_content,
                'metaTitle' => get_post_meta($page->ID, 'tatos_meta_title', true) ?: null,
                'metaDescription' => get_post_meta($page->ID, 'tatos_meta_description', true) ?: null,
                'data' => $data,
                'modified' => get_post_modified_time('c', true, $page),
            ]);
        },
    ]);

    register_rest_route('tatos/v1', '/categories', [
        'methods' => 'GET',
        'permission_callback' => $public,
        'callback' => function () {
            $terms = get_terms(['taxonomy' => 'categorie_produit', 'hide_empty' => false]);
            $out = array_map(fn($t) => [
                'slug' => $t->slug,
                'nom' => $t->name,
                'ordre' => (int) get_term_meta($t->term_id, 'ordre', true),
                'image' => get_term_meta($t->term_id, 'image', true) ?: null,
                'description' => get_term_meta($t->term_id, 'description_courte', true) ?: null,
            ], $terms);
            usort($out, fn($a, $b) => $a['ordre'] <=> $b['ordre']);
            return rest_ensure_response($out);
        },
    ]);

    register_rest_route('tatos/v1', '/products', [
        'methods' => 'GET',
        'permission_callback' => $public,
        'args' => ['page' => ['default' => 1, 'sanitize_callback' => 'absint'], 'per_page' => ['default' => 100, 'sanitize_callback' => 'absint']],
        'callback' => function (WP_REST_Request $req) {
            $per = max(1, min(200, (int) $req['per_page']));
            $q = new WP_Query(['post_type' => 'produit', 'post_status' => 'publish', 'posts_per_page' => $per, 'paged' => max(1, (int) $req['page']), 'orderby' => 'date', 'order' => 'DESC']);
            $res = rest_ensure_response(array_map('tatos_product_to_array', $q->posts));
            $res->header('X-WP-Total', (string) $q->found_posts);
            $res->header('X-WP-TotalPages', (string) $q->max_num_pages);
            return $res;
        },
    ]);

    // Un produit publié, par identifiant commercial (synchronisation unitaire déclenchée par le webhook).
    register_rest_route('tatos/v1', '/products/(?P<id>[A-Za-z0-9]{1,64})', [
        'methods' => 'GET',
        'permission_callback' => $public,
        'callback' => function (WP_REST_Request $req) {
            $id = (string) $req['id'];
            $found = get_posts(['post_type' => 'produit', 'post_status' => 'publish', 'numberposts' => 1, 'meta_key' => 'tatos_id', 'meta_value' => $id]);
            if (!$found && preg_match('/^wp0*(\d+)$/', $id, $m)) {
                $post = get_post((int) $m[1]);
                $found = $post && $post->post_type === 'produit' && $post->post_status === 'publish' && !get_post_meta($post->ID, 'tatos_id', true) ? [$post] : [];
            }
            if (!$found) {
                return new WP_Error('tatos_not_found', 'Produit introuvable', ['status' => 404]);
            }
            return rest_ensure_response(tatos_product_to_array($found[0]));
        },
    ]);
});

/* -------------------------------------------------------------------------
 * Contenus au nom de Destocktatos (2.4.0) : les textes repris de l'ancien site (TATOS) — pages
 * légales, CGV, FAQ, produits, réglages — sont corrigés une fois, juste après la mise à jour :
 * nom de la société, boîte email du magasin, hébergeur réel. Les autres textes ne changent pas.
 * ---------------------------------------------------------------------- */
function tatos_rebrand_text(string $s): string
{
    $s = preg_replace('/tatos-electromenager@[a-z0-9.-]+\.[a-z]{2,}/i', 'contacts@destocktatos.com', $s);
    $s = preg_replace('/\bTATOS\b/', 'Destocktatos', $s);
    $s = preg_replace('/contact@exemple\.fr/i', 'contacts@destocktatos.com', $s);
    // Ancienne adresse (Sevran) et ancien téléphone : établissement de Poissy.
    $s = preg_replace('/15\+Rue\+Paul\+Langevin\+93270\+Sevran/i', '65+Rue+d%27Aigremont+78300+Poissy', $s);
    $s = preg_replace('/\b1[25] rue paul l(?:angevin|evangin)\b/iu', '65 Rue d’Aigremont', $s);
    $s = preg_replace('/\b93270 Sevran\b/i', '78300 Poissy', $s);
    $s = preg_replace('/^93270$/', '78300', $s);
    $s = preg_replace('/^Sevran$/i', 'Poissy', $s);
    $s = str_replace(['+33-6-51-64-41-84', '+33651644184'], ['+33-1-83-75-01-21', '+33183750121'], $s);
    $s = preg_replace_callback('/(?:\+33[\s.-]*\(?6\)?[\s.-]*51[\s.-]*64[\s.-]*41[\s.-]*84|\b0?6[\s.-]?51[\s.-]?64[\s.-]?41[\s.-]?84\b)/', fn($m) => str_starts_with(trim($m[0]), '+') ? '+33 1 83 75 01 21' : '01 83 75 01 21', $s);
    $s = preg_replace(
        '#Example Hosting<br\s*/?>456 avenue du Web<br\s*/?>69000 Lyon, France<br\s*/?>Téléphone : \+33 \(0\)4 56 78 90 12#u',
        'Hostinger International Ltd<br/>61 Lordou Vironos Street<br/>6023 Larnaca, Chypre<br/>Site : www.hostinger.fr',
        $s
    );
    return str_replace('Example Hosting', 'Hostinger International Ltd', $s);
}

function tatos_rebrand_value($v)
{
    if (is_string($v)) {
        return tatos_rebrand_text($v);
    }
    if (is_array($v)) {
        return array_map('tatos_rebrand_value', $v);
    }
    return $v;
}

/** Informations légales : réglages, sinon valeurs fournies par le gérant. */
function tatos_company(): array
{
    $s = tatos_settings();
    $c = [];
    foreach (TATOS_LEGAL_DEFAULTS as $k => $default) {
        $c[$k] = trim((string) ($s[$k] ?? '')) ?: $default;
    }
    $c['establishment'] = $c['legalEstablishment'];
    $c['siteName'] = $s['siteName'] ?? 'Destocktatos';
    return $c;
}

/** CGV, article 4 : paiement par virement bancaire avant livraison. */
function tatos_payment_html(): string
{
    $s = tatos_settings();
    $c = tatos_company();
    $iban = trim((string) ($s['bankIban'] ?? ''));
    $account = $iban === '' ? '' : sprintf(
        'Coordonnées bancaires du Vendeur : titulaire %s%s — IBAN %s%s%s.',
        esc_html(trim((string) ($s['bankHolder'] ?? '')) ?: $c['legalName']),
        !empty($s['bankName']) ? ' (' . esc_html($s['bankName']) . ')' : '',
        esc_html($iban),
        !empty($s['bankBic']) ? ' — BIC ' . esc_html($s['bankBic']) : '',
        !empty($s['bankReference']) ? ' — communication à indiquer : ' . esc_html($s['bankReference']) . ', suivie si possible du numéro de commande' : ' — référence à indiquer : le numéro de commande'
    );
    $paragraphs = array_filter([
        "Le prix de la commande est payable en totalité par virement bancaire, avant la livraison. Aucun paiement n'est effectué sur le site : aucune donnée bancaire de l'Acheteur n'y est saisie ni conservée.",
        "Dès la validation de sa commande, l'Acheteur reçoit par email la facture correspondante, qui indique le montant à régler, les coordonnées bancaires du Vendeur et la communication à mentionner sur le virement. Ces informations figurent également sur la page de confirmation de la commande et dans l'espace client.",
        $account,
        "Les articles commandés sont réservés dans l'attente du virement. La commande est préparée puis livrée après réception du paiement sur le compte du Vendeur ; l'Acheteur en est informé par email. À défaut de paiement, le Vendeur peut annuler la commande, ce dont l'Acheteur est également informé par email.",
    ]);
    return implode('', array_map(fn($p) => '<p>' . $p . '</p>', $paragraphs));
}

/** Mentions légales : médiation de la consommation (médiateur des réglages, sinon sur demande). */
function tatos_mediator_html(): string
{
    $s = tatos_settings();
    $c = tatos_company();
    $name = trim((string) ($s['legalMediatorName'] ?? ''));
    $url = trim((string) ($s['legalMediatorUrl'] ?? ''));
    $who = $name !== ''
        ? 'Le médiateur de la consommation dont relève ' . esc_html($c['legalName']) . ' est : ' . esc_html($name) . ($url !== '' ? ' — <a href="' . esc_url($url) . '">' . esc_html(preg_replace('#^https?://#', '', $url)) . '</a>' : '') . '.'
        : 'Les coordonnées du médiateur de la consommation compétent sont communiquées sur simple demande auprès du service client.';
    return '<p>Conformément aux articles L.611-1 et suivants du Code de la consommation, tout consommateur a le droit de recourir gratuitement à un médiateur de la consommation en vue de la résolution amiable d\'un litige qui l\'oppose à ' . esc_html($c['legalName']) . ' (' . esc_html($c['siteName']) . ').</p>'
        . '<p>Avant de saisir le médiateur, le consommateur doit avoir tenté de résoudre le litige directement auprès du service client, par une réclamation écrite adressée à ' . esc_html($s['email'] ?? '') . ' ou par courrier au ' . esc_html($c['establishment']) . '.</p>'
        . '<p>' . $who . '</p>';
}

/** Désignation du vendeur dans les CGV, puis blocs « Éditeur du site » et « Responsable du traitement ». */
function tatos_company_text(string $html): string
{
    $c = tatos_company();
    $seller = sprintf(
        'la société %s, %s au capital de %s, dont le siège social est situé %s, immatriculée au Registre du Commerce et des Sociétés sous le numéro %s (SIRET du siège : %s, TVA intracommunautaire : %s), dont l\'établissement est situé %s, représentée par %s, gérant, exploitant le site %s',
        $c['legalName'], $c['legalForm'], $c['legalCapital'], $c['legalHeadOffice'], $c['legalRcs'], $c['legalSiret'], $c['legalVat'], $c['establishment'], $c['legalDirector'], $c['siteName']
    );
    $html = preg_replace('/la société (?:Destocktatos|TATOS), société par actions simplifiée, dont le siège social est situé [^,]+, \d{5} [^,]+, immatriculée au Registre du Commerce et des Sociétés sous le numéro SIRET \d+, activité NAF APE : [^,]+, dirigée par [^,]+/u', esc_html($seller), $html);
    $html = preg_replace('/(Destocktatos)(, Service Clients| - Service DPO), /u', '$1 (' . esc_html($c['legalName']) . ')$2, ', $html);
    $settings = tatos_settings();
    $html = preg_replace('/\b0123456789\b/', esc_html((string) ($settings['phone'] ?? '')), $html);
    // Article 4 (carte bancaire, PayPal) et médiateur à compléter : remplacés tant qu'ils n'ont pas été réécrits.
    $html = preg_replace_callback('#(<h2[^>]*>\s*Article 4[^<]*</h2>)(.*?)(?=<h2|<!-- wp:heading|$)#su', fn($m) => preg_match('/PayPal|carte bancaire/i', $m[2]) ? $m[1] . tatos_payment_html() : $m[0], $html);
    $html = preg_replace_callback('#(<h2[^>]*>\s*Médiation de la consommation\s*</h2>)(.*?)(?=<h2|<!-- wp:heading|$)#su', fn($m) => preg_match('/\[(Nom du service|URL du site)/i', $m[2]) ? $m[1] . tatos_mediator_html() : $m[0], $html);
    $note = '<p>Ces informations sont tirées de Réglages → Site et magasin → Informations légales.</p>';
    $html = preg_replace('#(<h2[^>]*>\s*Éditeur du site\s*</h2>)(.*?)(?=<h2|<!-- wp:heading|$)#su', '$1' . $note, $html);
    return preg_replace('#(<h2[^>]*>\s*[0-9. ]*Responsable du traitement\s*</h2>)(.*?)(?=<h2|<!-- wp:heading|$)#su', '$1' . $note, $html);
}

/** Corrige les contenus enregistrés ; renvoie le nombre d'éléments modifiés. */
function tatos_rebrand_contents(): int
{
    global $wpdb;
    $count = 0;
    // Réglages d'abord : les pages reprennent ensuite l'adresse et les informations légales corrigées.
    $settings = (array) get_option('tatos_settings', []);
    $fixed = tatos_rebrand_value($settings);
    foreach (TATOS_LEGAL_DEFAULTS as $k => $default) {
        if (trim((string) ($fixed[$k] ?? '')) === '') {
            $fixed[$k] = $default;
        }
    }
    if (trim((string) ($fixed['bankIban'] ?? '')) === '') {
        $fixed = array_merge($fixed, TATOS_BANK_DEFAULTS);
    }
    // Adresse saisie en entier dans « Adresse » : code postal, ville et pays en sont tirés.
    if (preg_match('/^(.+?),\s*(\d{5})\s+([^,]+?)(?:,\s*([^,]+?))?\s*$/u', (string) ($fixed['addressLine'] ?? ''), $m)) {
        $fixed['addressLine'] = trim($m[1]);
        $fixed['postalCode'] = $m[2];
        $fixed['city'] = trim($m[3]);
        if (!empty($m[4])) {
            $fixed['country'] = trim($m[4]);
        }
    }
    if ($fixed !== $settings) {
        update_option('tatos_settings', $fixed);
        $count++;
    }
    $types = "'page','post','faq','produit','nav_menu_item'";
    $posts = $wpdb->get_results("SELECT ID, post_title, post_content, post_excerpt FROM {$wpdb->posts} WHERE post_type IN ($types) AND (post_title LIKE '%TATOS%' OR post_content LIKE '%TATOS%' OR post_excerpt LIKE '%TATOS%' OR post_content LIKE '%Example Hosting%' OR post_content LIKE '%tatos-electromenager@%' OR post_content LIKE '%Sevran%' OR post_content LIKE '%51 64 41 84%' OR post_content LIKE '%exemple.fr%' OR post_content LIKE '%Éditeur du site%' OR post_content LIKE '%Responsable du traitement%' OR post_content LIKE '%PayPal%' OR post_content LIKE '%Nom du service de m%' OR post_content LIKE '%0123456789%')");
    foreach ($posts as $p) {
        $data = ['post_title' => tatos_rebrand_text($p->post_title), 'post_content' => tatos_company_text(tatos_rebrand_text($p->post_content)), 'post_excerpt' => tatos_rebrand_text($p->post_excerpt)];
        if ($data['post_title'] !== $p->post_title || $data['post_content'] !== $p->post_content || $data['post_excerpt'] !== $p->post_excerpt) {
            $wpdb->update($wpdb->posts, $data, ['ID' => $p->ID]);
            clean_post_cache((int) $p->ID);
            $count++;
        }
    }
    $metas = $wpdb->get_results("SELECT meta_id, post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_value LIKE '%TATOS%' OR meta_value LIKE '%Example Hosting%' OR meta_value LIKE '%tatos-electromenager@%' OR meta_value LIKE '%Sevran%' OR meta_value LIKE '%Langevin%' OR meta_value LIKE '%51644184%' OR meta_value LIKE '%51 64 41 84%' OR meta_value LIKE '%exemple.fr%'");
    foreach ($metas as $m) {
        $value = maybe_unserialize($m->meta_value);
        $fixed = tatos_rebrand_value($value);
        if ($fixed !== $value) {
            $wpdb->update($wpdb->postmeta, ['meta_value' => maybe_serialize($fixed)], ['meta_id' => $m->meta_id]);
            wp_cache_delete((int) $m->post_id, 'post_meta');
            $count++;
        }
    }
    $terms = $wpdb->get_results("SELECT t.term_id, t.name, tt.term_taxonomy_id, tt.description FROM {$wpdb->terms} t JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id WHERE t.name LIKE '%TATOS%' OR tt.description LIKE '%TATOS%'");
    foreach ($terms as $t) {
        $wpdb->update($wpdb->terms, ['name' => tatos_rebrand_text($t->name)], ['term_id' => $t->term_id]);
        $wpdb->update($wpdb->term_taxonomy, ['description' => tatos_rebrand_text($t->description)], ['term_taxonomy_id' => $t->term_taxonomy_id]);
        clean_term_cache((int) $t->term_id);
        $count++;
    }
    return $count;
}

add_action('admin_init', function () {
    if (get_option('tatos_rebrand_done') === '2.7.0' || !current_user_can('manage_options')) {
        return;
    }
    // Un seul avis au site à la fin (pas un par contenu corrigé).
    $GLOBALS['tatos_suspend_webhooks'] = true;
    $count = tatos_rebrand_contents();
    $GLOBALS['tatos_suspend_webhooks'] = false;
    update_option('tatos_rebrand_done', '2.7.0', false);
    if ($count > 0) {
        tatos_notify_frontend('content.updated', ['type' => 'rebrand']);
        set_transient('tatos_rebrand_notice', $count, 300);
    }
});

add_action('admin_notices', function () {
    $count = get_transient('tatos_rebrand_notice');
    if ($count) {
        delete_transient('tatos_rebrand_notice');
        printf('<div class="notice notice-success is-dismissible"><p>Contenus mis au nom de Destocktatos (société REIMS GOLD, établissement de Poissy) : %d élément(s) corrigé(s) — pages, CGV, mentions légales, produits, réglages. Vérifiez Réglages → Site et magasin → Informations légales.</p></div>', (int) $count);
    }
});

/* -------------------------------------------------------------------------
 * Mises à jour automatiques de l'extension, publiées avec le site
 * Le site expose /telechargements/tatos-headless.json (version) et l'archive de l'extension :
 * WordPress propose la mise à jour et l'installe de lui-même (mises à jour automatiques activées).
 * ---------------------------------------------------------------------- */
function tatos_update_info(): ?array
{
    $cached = get_site_transient('tatos_update_info');
    if (is_array($cached)) {
        return $cached ?: null;
    }
    $base = tatos_site_url();
    $info = [];
    if ($base !== '') {
        $res = wp_remote_get($base . '/telechargements/tatos-headless.json?t=' . time(), ['timeout' => 10, 'headers' => ['Cache-Control' => 'no-cache']]);
        $data = !is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200 ? json_decode(wp_remote_retrieve_body($res), true) : null;
        if (is_array($data) && !empty($data['version']) && preg_match('/^\d+\.\d+\.\d+$/', (string) $data['version'])) {
            $info = ['version' => (string) $data['version'], 'package' => $base . '/telechargements/tatos-headless.zip?v=' . rawurlencode((string) $data['version'])];
        }
    }
    set_site_transient('tatos_update_info', $info, 3 * HOUR_IN_SECONDS);
    return $info ?: null;
}

add_filter('pre_set_site_transient_update_plugins', function ($transient) {
    if (!is_object($transient)) {
        return $transient;
    }
    $file = plugin_basename(__FILE__);
    $info = tatos_update_info();
    $item = (object) ['id' => $file, 'slug' => 'tatos-headless', 'plugin' => $file, 'new_version' => TATOS_HEADLESS_VERSION, 'url' => tatos_site_url(), 'package' => ''];
    if ($info && version_compare($info['version'], TATOS_HEADLESS_VERSION, '>')) {
        $item->new_version = $info['version'];
        $item->package = $info['package'];
        $transient->response[$file] = $item;
        unset($transient->no_update[$file]);
    } else {
        $transient->no_update[$file] = $item;
        unset($transient->response[$file]);
    }
    return $transient;
});

// Installée automatiquement par WordPress, comme une extension officielle.
add_filter('auto_update_plugin', function ($update, $item) {
    return isset($item->plugin) && $item->plugin === plugin_basename(__FILE__) ? true : $update;
}, 10, 2);

// Après une mise à jour, la version publiée est relue tout de suite.
add_action('upgrader_process_complete', fn() => delete_site_transient('tatos_update_info'));

/* -------------------------------------------------------------------------
 * Webhook : prévient le frontend à chaque modification de contenu
 * ---------------------------------------------------------------------- */
/**
 * Adresse et secret du webhook : réglages dédiés, ou à défaut l'adresse publique du site et la clé
 * d'administration (déjà saisies pour la liaison). Ainsi chaque modification est transmise au site,
 * même si les champs du webhook sont restés vides.
 */
function tatos_webhook_target(): ?array
{
    $s = tatos_settings();
    $url = trim((string) ($s['webhookUrl'] ?? ''));
    if ($url === '' && tatos_site_url() !== '') {
        $url = tatos_site_url() . '/api/webhooks/wordpress';
    }
    $secret = trim((string) ($s['webhookSecret'] ?? '')) ?: trim((string) ($s['adminApiSecret'] ?? ''));
    return $url !== '' && $secret !== '' ? ['url' => $url, 'secret' => $secret] : null;
}

/** Envoie l'événement au site ; `$wait` attend sa réponse (test de la liaison). */
function tatos_send_webhook(string $event, array $payload = [], bool $wait = false)
{
    $target = tatos_webhook_target();
    if (!$target) {
        return new WP_Error('tatos_webhook', 'Adresse publique du site ou clé d\'administration manquante (Réglages → Site et magasin).');
    }
    return wp_remote_post($target['url'], [
        'timeout' => $wait ? 20 : 5,
        'blocking' => $wait,
        'headers' => ['Content-Type' => 'application/json', 'X-Tatos-Secret' => $target['secret'], 'Cache-Control' => 'no-cache'],
        'body' => wp_json_encode(['event' => $event] + $payload),
    ]);
}

function tatos_notify_frontend(string $event, array $payload = []): void
{
    // Suspendu pendant les imports en masse (un seul événement « sync.full » est envoyé à la fin).
    if (!empty($GLOBALS['tatos_suspend_webhooks'])) {
        return;
    }
    tatos_send_webhook($event, $payload);
}

// wp_after_insert_post (et non save_post) : déclenché une fois l'article, ses termes ET ses
// métadonnées enregistrés, y compris quand l'éditeur de blocs sauvegarde les méta via REST.
add_action('wp_after_insert_post', function ($post_id, $post) {
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id) || in_array($post->post_status, ['auto-draft', 'inherit'], true)) {
        return;
    }
    if ($post->post_type === 'nav_menu_item') {
        return; // couvert par l'événement menu.updated
    }
    $payload = ['type' => $post->post_type, 'slug' => $post->post_name, 'status' => $post->post_status];
    if ($post->post_type === 'produit') {
        $payload['id'] = tatos_product_id($post_id);
    }
    tatos_notify_frontend($post->post_type === 'produit' ? 'product.updated' : 'content.updated', $payload);
}, 10, 2);
// before_delete_post : les métadonnées (identifiant commercial) sont encore lisibles.
add_action('before_delete_post', function ($post_id, $post) {
    if ($post->post_type === 'produit') {
        tatos_notify_frontend('product.deleted', ['type' => 'produit', 'id' => tatos_product_id($post_id)]);
    } elseif ($post->post_type !== 'revision' && $post->post_type !== 'nav_menu_item') {
        tatos_notify_frontend('content.deleted', ['type' => $post->post_type, 'slug' => $post->post_name]);
    }
}, 10, 2);
add_action('wp_update_nav_menu', fn() => tatos_notify_frontend('menu.updated'));
add_action('update_option_tatos_settings', fn() => tatos_notify_frontend('settings.updated'));

/* -------------------------------------------------------------------------
 * WP-CLI : wp tatos import <fichier.json>
 * ---------------------------------------------------------------------- */
require_once __DIR__ . '/includes/site-api.php';
require_once __DIR__ . '/includes/editors.php';
require_once __DIR__ . '/includes/admin-shop.php';
require_once __DIR__ . '/includes/admin-help.php';
require_once __DIR__ . '/includes/importer.php';

if (defined('WP_CLI') && WP_CLI) {
    require_once __DIR__ . '/includes/class-tatos-cli.php';
    WP_CLI::add_command('tatos', 'Tatos_CLI');
}
